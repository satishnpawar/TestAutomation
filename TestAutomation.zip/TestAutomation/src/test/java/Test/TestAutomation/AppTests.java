package Test.TestAutomation;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import POJO.LounchBrowser;
import POM.LoginPage;
import POM.Page;
import junit.framework.Assert;

public class AppTests {
	WebDriver driver = new ChromeDriver();
	LoginPage page = new LoginPage();
	
	@BeforeTest
	public void  lounchbrowser() throws IOException {
		LounchBrowser.lounchBrowser("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}
	
	@Test
	public void login() {
				
		page.inserUsername();
		page.insertPassword();
		page.clickOnLogin();
		page.verifyPage();
		
	
		page.clickOnAdmin();
		page.clickSecondEditIcon();
		page.VerifyUserRole();
	}
	
	@AfterTest
	public void closeBrowser()
	{
		driver.close();
	}
	
	

}

package POM;

import org.mockito.internal.stubbing.answers.Returns;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.sun.org.apache.bcel.internal.generic.Select;

public class LoginPage {
	private WebDriver driver = null;
	Actions action = new Actions(driver);
	Select slect= new Selevt()5;
	
	@FindBy(xpath="(//p[@class=\"oxd-text oxd-text--p\"])[1]") private WebElement usernameText;
	@FindBy(xpath="(//input[@class=\"oxd-input oxd-input--active\"])[1]") private WebElement userName;
	@FindBy(xpath="(//p[@class=\"oxd-text oxd-text--p\"])[2]") private WebElement passwordText;
	@FindBy(xpath="(//input[@class=\"oxd-input oxd-input--active\"])[2]") private WebElement password;
	@FindBy(xpath="//button[normalize-space()='Login']") private WebElement login;
	@FindBy(xpath="(//span[@class=\"oxd-text oxd-text--span oxd-main-menu-item--name\"])[1]")private WebElement admin;
	@FindBy(xpath="//h6[@class=\"oxd-text oxd-text--h6 oxd-topbar-header-breadcrumb-module\"]")private WebElement pageHeader;
	@FindBy(xpath="//span[normalize-space()='Admin']")private WebElement edit;
	@FindBy(xpath="//span[normalize-space()='Admin']")private WebElement userRole;
	@FindBy(xpath="(//div[@class=\"oxd-select-text-input\"])[1]")private WebElement BtnSubmit;
	@FindBy(xpath="(//div[@class=\"oxd-table-cell oxd-padding-cell\"])[9]")private WebElement gridDataAdmin;
	
	
	public void Page(WebDriver driver) {
		PageFactory.initElements(driver, this);
		
	}
	public void inserUsername() {
		String userNameText = usernameText.getText();
		System.out.println(userNameText);
		int l = userNameText.length();
		String substring = "";
		for (int i=l-5;i<=l-5;i++)
		{
			substring= substring+userNameText.charAt(i);
			
		}
		
		userName.sendKeys(substring);
		
	}

	public void insertPassword() {
		String passWordText = passwordText.getText();
		int l = passWordText.length();
		String substring = "";
		for (int i=l-8;i<=l-5;i++)
		{
			substring= substring+passWordText.charAt(i);
			
		}
		
		userName.sendKeys(substring);
	}
	
	
	public void clickOnLogin() {
		action.click(login).perform();
		
	}
	public void verifyPage()
	{
	String pageHeaderName = pageHeader.getText();
	Assert.assertEquals(pageHeaderName,"DashBoard");
	}
	public void clickOnAdmin()
	{
		action.click(admin).perform();
	}
	public void clickSecondEditIcon()
	{
		action.click(edit).perform();
	
	}
	
	public void VerifyUserRole() {
		String role =userRole.getText();
		if (role.equals("ESS"))
		{
			action.click(BtnSubmit).perform();;
						
		}
		else
		{
			WebElement dropdown = driver.findElement(By.xpath("(//div[@class=\"oxd-select-text-input\"])[1]"));
			
			Select.isValidShort(3);
			action.click(BtnSubmit).perform();;
			
		}
		Assert.assertEquals(gridDataAdmin.getText(), "Admin");
	}
	
	
	
}

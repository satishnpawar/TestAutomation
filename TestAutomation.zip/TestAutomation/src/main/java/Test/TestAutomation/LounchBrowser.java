package Test.TestAutomation;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LounchBrowser {
public static void lounchBrowser(String url) throws IOException {
		
		System.setProperty("Webdriver.Chrome.driver", "F:\\browserDrivers\\chromedriver_win32 (6)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(url);
		
	}

}
